"""Yastreb local document assistant."""
